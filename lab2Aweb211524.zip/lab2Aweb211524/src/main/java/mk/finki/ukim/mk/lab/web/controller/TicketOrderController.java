package mk.finki.ukim.mk.lab.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import lombok.AllArgsConstructor;
import mk.finki.ukim.mk.lab.model.TicketOrder;
import mk.finki.ukim.mk.lab.service.TicketOrderService;
import mk.finki.ukim.mk.lab.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/ticketOrder")
@AllArgsConstructor
public class TicketOrderController {

    TicketOrderService ticketOrderService;
    UserService userService;

    @GetMapping()
    public String getTicketOrder(HttpServletRequest req, Model model){

        String movieTitle = req.getParameter("movieTitle");
        String numTickets = req.getParameter("numTickets");
        String clientName = req.getParameter("clientName");

        TicketOrder ticketOrder = ticketOrderService.placeOrder(movieTitle,clientName,req.getRemoteAddr(),Integer.parseInt(numTickets));

        userService.addOrder(movieTitle,clientName,req.getRemoteAddr(),Integer.parseInt(numTickets));


        model.addAttribute("ticketOrder",ticketOrder);

        return "orderConfirmation";
    }

    public String ticketOrder(@RequestParam String movieTitle,
                              @RequestParam String numTickets,
                              @RequestParam String clientName,
                              Model model,
                              HttpServletRequest req) {
        model.addAttribute("movieTitle", movieTitle);
        model.addAttribute("numTickets", numTickets);
        model.addAttribute("clientName", clientName);

        // Your other logic
        TicketOrder ticketOrder = ticketOrderService.placeOrder(movieTitle,clientName,req.getRemoteAddr(),Integer.parseInt(numTickets));

        userService.addOrder(movieTitle,clientName,req.getRemoteAddr(),Integer.parseInt(numTickets));


        model.addAttribute("ticketOrder",ticketOrder);

        return "orderConfirmation";
    }

    @PostMapping()
    public String buyTicket(@RequestParam String movieTitle,
                            @RequestParam String numTickets,
                            @RequestParam String clientName,
                            RedirectAttributes redirectAttributes){
        redirectAttributes.addAttribute("movieTitle", movieTitle);
        redirectAttributes.addAttribute("numTickets", numTickets);
        redirectAttributes.addAttribute("clientName", clientName);

        return "redirect:/ticketOrder";
    }

}