package mk.finki.ukim.mk.lab.web.controller;


import mk.finki.ukim.mk.lab.model.Movie;
import mk.finki.ukim.mk.lab.model.Production;
import mk.finki.ukim.mk.lab.service.MovieService;
import mk.finki.ukim.mk.lab.service.ProductionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/movies")
public class MovieController {

    private final ProductionService productionService;
    private final MovieService movieService;

    public MovieController(ProductionService productionService, MovieService movieService) {
        this.productionService = productionService;
        this.movieService = movieService;
    }

    @GetMapping()
    public String getMoviesPage(@RequestParam(required = false) String error, Model model) {
        if (error != null && !error.isEmpty()) {
            model.addAttribute("hasError", true);
            model.addAttribute("error", error);
        }
        List<Production> productions = productionService.findAll();
        model.addAttribute("productions", productions);
        model.addAttribute("movies", movieService.listAll());
        return "listMovies";
    }


    @GetMapping("/add-form")
    public String addMoviePage(Model model){
        List<Movie> movies = movieService.listAll();
        List<Production> productions = productionService.findAll();
        model.addAttribute("movies",movies);
        model.addAttribute("productions",productions);

        return "add-movie";
    }

    @PostMapping("/add")
    public String saveMovie(@RequestParam String movieTitle,
                            @RequestParam String summary,
                            @RequestParam double rating,
                            @RequestParam Long id) {

        Movie movie = movieService.saveMovie(movieTitle, summary, rating,id);

        return "redirect:/movies";
    }

    @GetMapping("/edit/{movieId}")
    public String editMovieForm(@PathVariable Long movieId, Model model) {

        Movie existingMovie = movieService.findById(movieId);

        List<Production> productions = productionService.findAll();

        model.addAttribute("existingMovie", existingMovie);
        model.addAttribute("productions", productions);

        return "add-movie";
    }

    @GetMapping("/delete/{id}")
    public String deleteMovie(@PathVariable Long id, Model model){
        this.movieService.deleteById(id);
        return "redirect:/movies";
    }
}
