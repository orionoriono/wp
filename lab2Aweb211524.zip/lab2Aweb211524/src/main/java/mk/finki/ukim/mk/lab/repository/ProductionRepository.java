package mk.finki.ukim.mk.lab.repository;

import jakarta.annotation.PostConstruct;
import mk.finki.ukim.mk.lab.model.Production;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

@Repository
public class ProductionRepository {
    private List<Production> productions;
    private final MovieRepository movieRepository;

    public ProductionRepository(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }

    @PostConstruct
    public void init(){
        this.productions = Arrays.asList(
                new Production("Walt Disney Studios","United States","123 Magic Way, Enchantville, CA 98765, USA"),
                new Production("Warner Bros.Pictures","United States","456 Cinematic Lane, Dreamville, CA 54321, USA"),
                new Production("Universal Pictures","United States","789 Studio Street, Imagination City, CA 12345, USA"),
                new Production("Sony Pictures Entertainment","United States","101 Picture Plaza, Entertainmentville, CA 67890, USA"),
                new Production(" 20th Century Fox","United States","210 Cineworld Avenue, Foxborough, CA 13579, USA")
        );

        this.movieRepository
                .findAll()
                .forEach(movie -> movie.setProduction(this.productions.get(new Random().nextInt(1,5))));
    }
    public List<Production> findAll(){
        return productions;
    }

    public Production findById(Long id) {
        return this.productions.stream().filter(production -> production.getId().equals(id)).findFirst().orElse(null);
    }
}