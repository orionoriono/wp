package mk.finki.ukim.mk.lab.repository;

import lombok.Data;
import mk.finki.ukim.mk.lab.model.TicketOrder;
import mk.finki.ukim.mk.lab.model.User;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
@Data
public class UserRepository {
    private Map<String, List<TicketOrder>> ticketOrderMap = new HashMap<>();

    public void addOrder(String movieTitle,String clientName, String address, int numberOfTickets){
        if (!ticketOrderMap.containsKey(clientName))
            ticketOrderMap.put(clientName,new ArrayList<>());

        ticketOrderMap.get(clientName).add(new TicketOrder(movieTitle,clientName,address, (long) numberOfTickets));
    }

    public Map<String, List<TicketOrder>> getTicketOrderMap(){
        return ticketOrderMap;
    }

    public User findUser(String username) {
        String nameOfUser = ticketOrderMap.keySet().stream().filter(name -> name.equals(username)).findFirst().orElse(null);
        User user = new User(nameOfUser,ticketOrderMap.get(nameOfUser));
        return user;
    }

    public Set<String> users(){
        return ticketOrderMap.keySet();
    }
}