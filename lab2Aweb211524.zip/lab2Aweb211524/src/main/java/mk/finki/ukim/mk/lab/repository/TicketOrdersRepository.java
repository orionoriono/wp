package mk.finki.ukim.mk.lab.repository;

import lombok.AllArgsConstructor;
import mk.finki.ukim.mk.lab.model.TicketOrder;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@AllArgsConstructor
public class TicketOrdersRepository {

    private List<TicketOrder> ticketOrders;

    public TicketOrder ticketOrder(String movieTitle, String clientName, String address, int numberOfTickets){
        TicketOrder order = new TicketOrder(movieTitle,clientName,address, (long) numberOfTickets);
        ticketOrders.add(order);
        return order;
    }

    public List<TicketOrder> listAll(){
        return ticketOrders;
    }

}