package mk.finki.ukim.mk.lab.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import mk.finki.ukim.mk.lab.model.TicketOrder;
import mk.finki.ukim.mk.lab.model.User;
import mk.finki.ukim.mk.lab.service.impl.UserServiceImpl;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@WebServlet(urlPatterns = "/userTickets")
@AllArgsConstructor
public class UserTicketServlet extends HttpServlet {

    private final SpringTemplateEngine springTemplateEngine;
    private final UserServiceImpl userService;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        IWebExchange webExchange = JakartaServletWebApplication.buildApplication(getServletContext()).buildExchange(req,resp);
        WebContext webContext = new WebContext(webExchange);

        String name = req.getParameter("name");
        Set<String> users = userService.users();
        webContext.setVariable("users",users);

        if(name!=null && !name.isEmpty()) {
            User user = userService.findUser(name);
            webContext.setVariable("user",user);
            List<TicketOrder> userOrders = userService.getOrders().get(name);
            webContext.setVariable("userOrders",userOrders);
        }
        springTemplateEngine.process("showHistory.html",webContext,resp.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");

        if (name!=null)
            resp.sendRedirect("/userTickets?&name="+name);
        else
            resp.sendRedirect("/userTickets");
    }
}