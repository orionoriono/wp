package mk.finki.ukim.mk.lab.service;

import mk.finki.ukim.mk.lab.model.TicketOrder;
import mk.finki.ukim.mk.lab.model.User;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public interface UserService {
    void addOrder(String movieTitle, String clientName, String address, int numberOfTickets);
    Map<String,List<TicketOrder>> getOrders();

    public User findUser(String username);

    Set<String> users();
}