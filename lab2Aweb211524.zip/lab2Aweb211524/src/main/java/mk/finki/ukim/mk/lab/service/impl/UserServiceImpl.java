package mk.finki.ukim.mk.lab.service.impl;

import lombok.AllArgsConstructor;
import mk.finki.ukim.mk.lab.model.TicketOrder;
import mk.finki.ukim.mk.lab.model.User;
import mk.finki.ukim.mk.lab.repository.UserRepository;
import mk.finki.ukim.mk.lab.service.UserService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;
    @Override
    public void addOrder(String movieTitle, String clientName, String address, int numberOfTickets) {
        userRepository.addOrder(movieTitle, clientName, address, numberOfTickets);
    }

    @Override
    public Map<String, List<TicketOrder>> getOrders() {
        return userRepository.getTicketOrderMap();
    }

    @Override
    public User findUser(String username) {
        return userRepository.findUser(username);
    }

    @Override
    public Set<String> users() {
        return userRepository.users();
    }


}